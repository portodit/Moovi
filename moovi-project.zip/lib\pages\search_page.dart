import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../models/movie.dart';
import '../widgets/movie_list.dart';

class SearchPage extends StatefulWidget {
  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final ApiService apiService = ApiService();
  List<Movie>? _movies;
  bool _isLoading = false;

  void _searchMovies(String query) async {
    setState(() {
      _isLoading = true;
    });
    final movies = await apiService.searchMovies(query);
    setState(() {
      _movies = movies;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          decoration: InputDecoration(
            hintText: 'Ketik Pencarian Movie...',
          ),
          onSubmitted: (query) {
            _searchMovies(query);
          },
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _movies == null
              ? Center(child: Text('Ketik Pencarian Movie'))
              : MovieList(movies: _movies!),
    );
  }
}
