package com.example.movi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
